# DWASim

This repository contains the implementation accompanying the manuscript
**“DWASim: Dynamic Weight Adjustment Similarity Method between Interactive
Entities and Their Connectivity.”**

DWASim constructs interpretable affinities between same-type entities in a
heterogeneous information network. The implementation supports global and
pair-relative normalization, path-specific combinations of support,
relative-magnitude, and directional evidence, multi-path fusion, nearest-
neighbour evaluation, and the PathSim, HeteSim, Jaccard, Bray--Curtis, cosine,
and Bhattacharyya comparison methods used by the study.

## Repository scope

The 2026-09-07 theory extension adds PSD-kernel diagnostics, regularized
kernel-target fitting and shared path-wise integer-power calibration. The
original method and all comparisons remain available. See
`KERNEL_EXTENSION.md` for the command order, fixed grids, negative results and
the distinction between mathematical guarantees and empirical performance.

The public repository intentionally contains source code and documentation
only. Benchmark records, processed matrices, cached computations, generated
metrics, and figures are not committed. They are obtained or generated
locally by the commands below and are excluded by `.gitignore`.

```text
DWASim/
├── src/                  experiment and plotting programs
├── tests/                data-independent unit tests
├── docs/
│   ├── DATASETS.md       benchmark provenance and local layout
│   └── EXPERIMENTS.md    script-to-experiment map
├── .gitignore
├── README.md
└── requirements.txt
```

## Environment

The reference environment uses Python 3.10 on CPU. A CUDA device is not
required.

```bash
python -m venv .venv
```

Activate the environment and install the dependencies:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

`requirements-lock.txt` additionally records all resolved transitive packages
from the clean Windows CPU environment validated on 2026-09-06. Install it
instead of `requirements.txt` when reproducing that complete environment.

## Benchmark setup

The HGBn-ACM, HGBn-DBLP, and HGBn-IMDB records are public third-party
benchmarks from the Heterogeneous Graph Benchmark project. They are not part
of this repository. Download them from the source described in
[`docs/DATASETS.md`](docs/DATASETS.md), and place the extracted records under:

```text
data/raw/ACM/
data/raw/DBLP/
data/raw/IMDB/
```

Each dataset directory must contain `node.dat`, `link.dat`, `label.dat`,
`label.dat.test`, and `info.dat`. Convert the records into the sparse relation
matrices used by the experiment programs:

```bash
python src/prepare_hgb.py --dataset all
```

The conversion validates node counts, verifies disjoint training and test
label sets, checks reverse-relation transposes, and records source-file hashes
in locally generated manifests.

## Main experiment commands

Run the three-path component and retrieval evaluation:

```bash
python src/run_support_retrieval_stress.py --dataset all --splits 10 --bootstrap-iterations 2000
python src/plot_support_retrieval_stress.py
```

Run the matched two-path normalization and fusion evaluations:

```bash
python src/run_real_multipath_fusion.py --dataset all --k 10 --splits 10
python src/run_unified_normalization_validation.py --dataset all --bootstrap-iterations 2000
python src/plot_real_multipath_fusion.py
```

Run the external multi-label evaluation:

```bash
python src/run_imdb_external_validation.py --bootstrap-iterations 2000
```

Run the revision-stage diagnostics that support the manuscript's component,
representation, mechanism, and cost analyses:

```bash
python src/run_revision_controls.py --dataset all --outer-repeats 5 --bootstrap-iterations 2000
python src/run_representation_controls.py
python src/run_controlled_mechanisms.py
python src/benchmark_revision_cost.py
python src/run_path_fusion_audit.py --dataset all
python src/benchmark_pipeline_cost.py --dataset all --method all
python src/run_regularized_selection.py --dataset all
```

The quantitative manuscript assets can then be regenerated with
`python src/build_revision_assets.py`. This command reads local generated
records and writes tables to `manuscript_assets/revision_tables/` and
vector/raster figures directly to `manuscript_assets/`. Both are ignored.
Use `--tables-only` to retain existing figures, or `--output PATH` to choose
another destination. It does not download or embed benchmark records.

The path-fusion audit holds within-path components fixed while comparing
training-selected best-single-path, uniform-path, and learned-path fusion.
It also refits all three controls in five outer training partitions. The
pipeline benchmark recomputes derived profiles and components, refits the
selected method, and checks output-preserving zero-weight inference against
the full computation. Run this benchmark without other intensive work; it
executes dataset/method workers serially. Its single-run times are descriptive.

Additional audit and development programs are documented in
[`docs/EXPERIMENTS.md`](docs/EXPERIMENTS.md).

The regularized-selection experiment tests a fixed 0.005 internal Macro-F1
tolerance for component screening and five shrinkage strengths toward uniform
path weights. It refits all stages in five outer training partitions before
official-test evaluation. Cosine and single-component controls receive the same
shrinkage rule. All ten rules and all partitions are retained; the experiment
does not replace the main method using the observed test rankings. Completed
result records are protected from accidental overwrite; use `--output-dir PATH`
for a separate rerun. The standalone table command is
`python src/build_regularized_assets.py`; the main asset builder also includes
these tables when both dataset runs are present. See
[`docs/REGULARIZATION_PROTOCOL.md`](docs/REGULARIZATION_PROTOCOL.md) for the frozen
design. These variants currently apply to ACM and DBLP, not IMDB.

All parameter and path-weight selection is performed with training labels.
No selection function receives official test labels; they are used to evaluate
the frozen predictions, not to choose parameters.
Tie handling and random seeds are deterministic in the corrected evaluation
programs. Revision-stage comparisons are documented as such in the paper.

## Tests

The repository includes unit tests that do not require benchmark or result
files:

```bash
python -m unittest discover -s tests -v
```

These tests cover the PathSim and HeteSim formulas, rectangular HeteSim,
deterministic ranking and voting, simplex weights, pair-relative affinities,
multi-label decisions, NDCG, and cache-key stability.

## Generated directories

The programs create the following directories when needed:

- `data/processed/` for converted sparse relations and label mappings;
- `cache/` for reusable intermediate computations;
- `results/` for generated evaluation records;
- `figures/` for generated visualizations.
- `manuscript_assets/` for the current manuscript's generated tables and figures.

These artifacts remain local and are intentionally excluded from version
control.
## Current experimental figures

The evidence-led figures and consolidated tables are documented in
[`FIGURE_REVISION.md`](FIGURE_REVISION.md). The general asset builder runs the
current figure module after building the other tables. It recomputes descriptive
affinity diagnostics in double precision and verifies all frozen prediction
metrics before export. No model selection or benchmark scores are changed.
