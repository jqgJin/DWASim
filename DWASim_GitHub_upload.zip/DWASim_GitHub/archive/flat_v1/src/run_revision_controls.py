"""Frozen revision controls for component necessity and selection stability.

All model selection uses official training labels. Test metrics are descriptive
revision-stage evaluations, not an untouched or preregistered holdout claim.
"""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path
import numpy as np
from reproduce_original import RESULTS_ROOT, full_profile
from run_corrected_protocol import load_split
from run_real_multipath_fusion import split_positions
from run_nested_multipath_optimization import simplex_weights
from evidence_diagnostics import affinity_statistics, nullable
from run_support_retrieval_stress import (
    STRESS_PATHS, load_components, select_path_mixture, select_fusion,
    evaluate_affinity, paired_bootstrap,
)

FAMILIES = ("TriComponentDWASim", "Cosine", "OneComponentSelector", "FixedEqualMixture",
            "SharedComponentMixture", "JointBudget60", "NoSupport", "NoMagnitude", "NoDirection",
            "PTPNoSupport")
INNER_SEEDS = list(range(20250803, 20250813))


def component_views(components, prefix="train"):
    return [1 - components[f"{prefix}_jaccard"], 1 - components[f"{prefix}_bray"],
            components[f"{prefix}_cosine"]]


def weighted_view(views, weights):
    return sum(float(weight) * view for weight, view in zip(weights, views) if weight != 0)


def joint_candidates():
    # Sixty candidates, equal to 3*15 path-component candidates plus 15 fusion candidates.
    rng = np.random.default_rng(20260905)
    return [*np.eye(9).tolist(), [1 / 9] * 9, *rng.dirichlet(np.ones(9), size=50).tolist()]


def select_linear(views, candidates, ids, labels, splits, k=10):
    rows = []
    for candidate in candidates:
        affinity = weighted_view(views, candidate)
        metrics = [evaluate_affinity(affinity[np.ix_(validation, reference)], ids[reference],
                    labels[reference], labels[validation], k)[0] for reference, validation in splits]
        rows.append({"weights": list(candidate),
                     "macro_f1_mean": float(np.mean([m["macro_f1"] for m in metrics])),
                     "ndcg_at_10_mean": float(np.mean([m["ndcg_at_10"] for m in metrics]))})
    best = max(rows, key=lambda row: (row["macro_f1_mean"], row["ndcg_at_10_mean"],
                                      -np.count_nonzero(row["weights"])))
    return {"selected": best, "grid": rows}


def fit_family(family, components, ids, labels, splits, paths):
    started = time.perf_counter()
    base = [component_views(c) for c in components]
    component_grid = simplex_weights(3, 0.25)
    if family == "JointBudget60":
        selection = select_linear([view for path in base for view in path], joint_candidates(), ids, labels, splits)
        gamma = np.asarray(selection["selected"]["weights"]).reshape(3, 3)
        return {"gamma": gamma.tolist(), "component_weights": None, "path_weights": gamma.sum(axis=1).tolist(),
                "candidate_count": 60, "validation_macro_f1": selection["selected"]["macro_f1_mean"],
                "selection_seconds": time.perf_counter() - started, "joint_grid": selection["grid"]}
    if family == "SharedComponentMixture":
        shared = [sum(path[j] for path in base) / len(paths) for j in range(3)]
        selected = select_linear(shared, component_grid, ids, labels, splits)
        chosen = [selected["selected"]["weights"]] * len(paths)
        candidate_count = len(component_grid)
    else:
        chosen, candidate_count = [], 0
        for path, values in zip(paths, components):
            if family == "Cosine":
                chosen.append([0., 0., 1.])
                continue
            if family == "MagnitudeOnly":
                chosen.append([0., 1., 0.])
                continue
            if family == "Jaccard":
                chosen.append([1., 0., 0.])
                continue
            if family == "FixedEqualMixture":
                chosen.append([1 / 3] * 3)
                continue
            grid = component_grid
            if family == "OneComponentSelector":
                grid = [tuple(row) for row in np.eye(3)]
            elif family in ("NoSupport", "NoMagnitude", "NoDirection"):
                omitted = ("NoSupport", "NoMagnitude", "NoDirection").index(family)
                grid = [row for row in component_grid if row[omitted] == 0]
            elif family == "PTPNoSupport" and path == "PTP":
                grid = [row for row in component_grid if row[0] == 0]
            selection = select_path_mixture(values, ids, labels, splits, grid, 10)
            chosen.append(selection["selected"]["weights_support_magnitude_direction"])
            candidate_count += len(grid)
    train_views = [weighted_view(view, weights) for view, weights in zip(base, chosen)]
    fusion_grid = simplex_weights(len(paths), 0.25)
    fusion = select_fusion(train_views, ids, labels, splits, fusion_grid, 10)
    path_weights = fusion["selected"]["weights"]
    gamma = np.asarray(chosen) * np.asarray(path_weights)[:, None]
    return {"gamma": gamma.tolist(), "component_weights": chosen, "path_weights": path_weights,
            "candidate_count": candidate_count + len(fusion_grid),
            "validation_macro_f1": fusion["selected"]["macro_f1_mean"],
            "selection_seconds": time.perf_counter() - started}


def predict_affinity(components, fitted, prefix="test"):
    return sum(weighted_view(component_views(values, prefix), gamma)
               for values, gamma in zip(components, fitted["gamma"]) if np.sum(gamma) > 0)


def subset_components(components, references, queries):
    answer = []
    for values in components:
        row = {}
        for name in ("jaccard", "bray", "cosine", "bhattacharyya", "pathsim", "hetesim"):
            if f"train_{name}" in values:
                row[f"train_{name}"] = values[f"train_{name}"][np.ix_(references, references)]
                row[f"test_{name}"] = values[f"train_{name}"][np.ix_(queries, references)]
        answer.append(row)
    return answer


def summarize_rows(rows, metric):
    values = np.array([row[metric] for row in rows])
    return {"mean": float(values.mean()), "sample_sd": float(values.std(ddof=1)) if len(values) > 1 else 0.}


def run_dataset(dataset, outer_repeats, bootstrap_iterations):
    started = time.perf_counter()
    ids, labels, test_ids, truth = load_split(dataset)
    paths = STRESS_PATHS[dataset]
    components = [load_components(dataset, path) for path in paths]
    splits = split_positions(labels, INNER_SEEDS, 0.2)
    families = [name for name in FAMILIES if name != "PTPNoSupport" or dataset == "ACM"]
    fitted, predictions, ndcg, metrics = {}, {}, {}, {}
    for family in families:
        model = fit_family(family, components, ids, labels, splits, paths)
        fitted[family] = model
        metric, pred, query_ndcg = evaluate_affinity(predict_affinity(components, model), ids, labels, truth, 10)
        metrics[family], predictions[family], ndcg[family] = metric, pred, query_ndcg
        print(dataset, family, json.dumps(metric), flush=True)

    singles, diagnostics = {}, {}
    for path, values in zip(paths, components):
        profiles = full_profile(dataset, path)
        upper = np.triu_indices(len(ids), k=1)
        scores = np.stack([v[upper] for v in component_views(values)], axis=1)
        variance, correlation = affinity_statistics(scores)
        diagnostics[path] = {"complete_profile_shape": list(profiles.shape),
            "nonzero_density": float(profiles.nnz / np.prod(profiles.shape)),
            "full_support_rows": int(np.sum(np.diff(profiles.indptr) == profiles.shape[1])),
            "component_variance": variance.tolist(), "component_correlation": nullable(correlation),
            "support_affinity_equal_one_fraction": float(np.mean(scores[:, 0] == 1)),
            "training_unordered_pairs": len(scores)}
        singles[path] = {}
        for name, affinity in (("Jaccard", 1-values["test_jaccard"]), ("MagnitudeOnly", 1-values["test_bray"]),
                              ("Cosine", values["test_cosine"]), ("Bhattacharyya", values["test_bhattacharyya"]),
                              ("PathSim", values["test_pathsim"]), ("HeteSim", values["test_hetesim"])):
            singles[path][name] = evaluate_affinity(affinity, ids, labels, truth, 10)[0]

    outer_rows = []
    outer_splits = split_positions(labels, list(range(20260910, 20260910 + outer_repeats)), 0.2)
    for index, (outer_train, outer_validation) in enumerate(outer_splits):
        inner = split_positions(labels[outer_train], INNER_SEEDS, 0.2)
        sub = subset_components(components, outer_train, outer_validation)
        record = {"repeat": index, "outer_reference_ids": ids[outer_train].tolist(),
                  "outer_validation_ids": ids[outer_validation].tolist(), "methods": {}}
        for family in ("TriComponentDWASim", "Cosine", "OneComponentSelector", "NoSupport"):
            model = fit_family(family, sub, ids[outer_train], labels[outer_train], inner, paths)
            metric = evaluate_affinity(predict_affinity(sub, model), ids[outer_train], labels[outer_train],
                                       labels[outer_validation], 10)[0]
            record["methods"][family] = {"selection": model, "metrics": metric}
        outer_rows.append(record)
        print(dataset, "outer", index + 1, {name: round(row["metrics"]["macro_f1"], 4)
               for name, row in record["methods"].items()}, flush=True)
    outer_summary = {}
    for family in ("TriComponentDWASim", "Cosine", "OneComponentSelector", "NoSupport"):
        method_rows = [row["methods"][family]["metrics"] for row in outer_rows]
        if method_rows:
            outer_summary[family] = {name: summarize_rows(method_rows, name) for name in ("macro_f1", "ndcg_at_10")}

    paired = {}
    for index, comparator in enumerate(name for name in families if name != "TriComponentDWASim"):
        paired[comparator] = paired_bootstrap(truth, predictions["TriComponentDWASim"], predictions[comparator],
            ndcg["TriComponentDWASim"], ndcg[comparator], bootstrap_iterations, 20260905 + index)
    RESULTS_ROOT.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(RESULTS_ROOT / f"revision_controls_{dataset}.predictions.npz", test_ids=test_ids, truth=truth,
        **{f"prediction_{key}": value for key, value in predictions.items()},
        **{f"ndcg_{key}": value for key, value in ndcg.items()})
    return {"dataset": dataset, "paths": list(paths), "selection": fitted, "test_metrics": metrics,
            "paired_final_minus_comparator": paired, "single_path_metrics": singles,
            "component_diagnostics": diagnostics, "outer_repeats": outer_rows, "outer_summary": outer_summary,
            "elapsed_seconds": time.perf_counter() - started}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=("ACM", "DBLP", "all"), default="all")
    parser.add_argument("--outer-repeats", type=int, default=5)
    parser.add_argument("--bootstrap-iterations", type=int, default=2000)
    args = parser.parse_args()
    datasets = ("ACM", "DBLP") if args.dataset == "all" else (args.dataset,)
    for dataset in datasets:
        record = run_dataset(dataset, args.outer_repeats, args.bootstrap_iterations)
        record["protocol"] = {"inner_seeds": INNER_SEEDS, "outer_seed_start": 20260910,
            "outer_repeats": args.outer_repeats, "bootstrap_iterations": args.bootstrap_iterations,
            "joint_budget": 60, "joint_seed": 20260905, "primary_comparators": ["Cosine", "OneComponentSelector"],
            "inference": "Descriptive fixed-graph paired intervals; overlapping outer partitions are not independent graphs."}
        output = RESULTS_ROOT / f"revision_controls_{dataset}.json"
        output.write_text(json.dumps(record, indent=2), encoding="utf-8")
        print("Wrote", output, flush=True)


if __name__ == "__main__":
    main()
