"""Fixed path-wise integer-power calibration with matched component controls."""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from reproduce_original import RESULTS_ROOT
from run_corrected_protocol import load_split
from run_real_multipath_fusion import split_positions
from run_revision_controls import INNER_SEEDS, component_views, weighted_view
from run_regularized_selection import best_row
from run_nested_multipath_optimization import simplex_weights
from run_support_retrieval_stress import STRESS_PATHS, load_components, evaluate_affinity, paired_bootstrap

POWERS = (1, 2, 4)
FAMILIES = ("PowerDWASim", "PowerMagnitude", "PowerCosine", "PowerNoSupport", "PowerNoMagnitude", "PowerNoDirection")
OUTER_SEEDS = tuple(range(20260910, 20260915))


def power_affinity(views, weights, power):
    if power not in POWERS:
        raise ValueError("Only the fixed positive integer power grid is supported")
    return weighted_view([v if power == 1 else v**power for v in views], weights)


def within_weights(grids, family):
    if family in ("PowerMagnitude", "PowerCosine"):
        return [[0.,1.,0.] if family == "PowerMagnitude" else [0.,0.,1.] for _ in grids]
    omitted = {"PowerNoSupport": 0, "PowerNoMagnitude": 1, "PowerNoDirection": 2}.get(family)
    return [best_row([r for r in rows if omitted is None or r["weights"][omitted] == 0], True)["weights"] for rows in grids]


def fit(components, grids, ids, labels):
    started = time.perf_counter()
    splits = split_positions(labels, INNER_SEEDS, .2)
    models, candidates = {}, {}
    for family in FAMILIES:
        theta = within_weights(grids, family)
        views = [weighted_view(component_views(c), t) for c,t in zip(components,theta)]
        rows = []
        for power in POWERS:
            transformed = [v if power == 1 else v**power for v in views]
            for weights in simplex_weights(3,.25):
                affinity = weighted_view(transformed, weights)
                folds = [evaluate_affinity(affinity[np.ix_(q,r)],ids[r],labels[r],labels[q],10)[0] for r,q in splits]
                rows.append({"power":power,"weights":list(weights),"folds":folds,
                             "macro_f1":float(np.mean([x["macro_f1"] for x in folds])),
                             "ndcg_at_10":float(np.mean([x["ndcg_at_10"] for x in folds]))})
        key = lambda row: (row["macro_f1"],row["ndcg_at_10"],-row["power"],-np.count_nonzero(row["weights"]))
        selected = max(rows,key=key)
        uncalibrated = max([r for r in rows if r["power"] == 1],key=key)
        models[family] = {"component_weights":theta,"path_weights":selected["weights"],
                          "power":selected["power"],"validation_macro_f1":selected["macro_f1"]}
        models[family+"P1"] = {"component_weights":theta,"path_weights":uncalibrated["weights"],
                               "power":1,"validation_macro_f1":uncalibrated["macro_f1"]}
        candidates[family] = rows
    return {"models":models,"grids":candidates,"cached_component_selection":True,"fusion_seconds":time.perf_counter()-started}


def affinity(components, model, prefix="test"):
    views = [weighted_view(component_views(c,prefix),t) for c,t in zip(components,model["component_weights"])]
    return power_affinity(views,model["path_weights"],model["power"])


def write_json(path, value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False),encoding="utf-8")


def run(dataset, output):
    output.mkdir(parents=True,exist_ok=True)
    target = output/f"kernel_power_{dataset}.json"
    checkpoint = output/f"kernel_power_{dataset}.checkpoint.json"
    if target.exists() or checkpoint.exists():
        raise FileExistsError("Existing outcomes are protected; choose a new output folder")
    start = time.perf_counter()
    oldpath = RESULTS_ROOT/f"regularized_selection_{dataset}.json"
    old = json.loads(oldpath.read_text())
    if old["protocol"]["inner_seeds"] != INNER_SEEDS or old["protocol"]["outer_seeds"] != list(OUTER_SEEDS):
        raise AssertionError("Cached component-selection partitions differ")
    ids, labels, test_ids, truth = load_split(dataset)
    components = [load_components(dataset,p) for p in STRESS_PATHS[dataset]]
    outer = []
    for index,(r,q) in enumerate(split_positions(labels,OUTER_SEEDS,.2)):
        cached = old["outer"][index]
        np.testing.assert_array_equal(ids[r],cached["reference_ids"])
        np.testing.assert_array_equal(ids[q],cached["validation_ids"])
        subset = [{f"{prefix}_{name}":c[f"train_{name}"][np.ix_(positions,r)]
                   for prefix,positions in (("train",r),("test",q)) for name in ("jaccard","bray","cosine")} for c in components]
        fitted = fit(subset,cached["fit"]["component_grids"],ids[r],labels[r])
        metrics = {name:evaluate_affinity(affinity(subset,model),ids[r],labels[r],labels[q],10)[0]
                   for name,model in fitted["models"].items()}
        for metric in ("macro_f1","ndcg_at_10"):
            if abs(metrics["PowerDWASimP1"][metric]-cached["metrics"]["Original"][metric]) > 1e-12:
                raise AssertionError("p=1 does not reproduce frozen outer control")
        outer.append({"seed":OUTER_SEEDS[index],"reference_ids":ids[r].tolist(),"validation_ids":ids[q].tolist(),
                      "fit":fitted,"metrics":metrics})
        write_json(checkpoint,{"outer":outer})
        print(dataset,"power outer",OUTER_SEEDS[index],{m:round(metrics[m]["macro_f1"],4) for m in FAMILIES},flush=True)
    fitted = fit(components,old["fit"]["component_grids"],ids,labels)
    write_json(output/f"kernel_power_{dataset}.frozen_fit.json",fitted)
    metrics,predictions,ndcgs = {},{},{}
    for name,model in fitted["models"].items():
        metrics[name],predictions[name],ndcgs[name] = evaluate_affinity(affinity(components,model),ids,labels,truth,10)
        print(dataset,"power official",name,"p",model["power"],metrics[name],flush=True)
    for metric in ("macro_f1","ndcg_at_10"):
        if abs(metrics["PowerDWASimP1"][metric]-old["test_metrics"]["Original"][metric]) > 1e-12:
            raise AssertionError("p=1 does not reproduce frozen official control")
    paired = {name:paired_bootstrap(truth,predictions["PowerDWASim"],predictions[name],ndcgs["PowerDWASim"],ndcgs[name],2000,20261101+i)
              for i,name in enumerate(metrics) if name != "PowerDWASim"}
    predpath = output/f"kernel_power_{dataset}.predictions.npz"
    np.savez_compressed(predpath,truth=truth,test_ids=test_ids,**{f"prediction_{k}":v for k,v in predictions.items()},
                       **{f"ndcg_{k}":v for k,v in ndcgs.items()})
    summary = {name:{metric:{"mean":float(np.mean([r["metrics"][name][metric] for r in outer])),
                             "sample_sd":float(np.std([r["metrics"][name][metric] for r in outer],ddof=1))}
                    for metric in ("macro_f1","ndcg_at_10")} for name in metrics}
    result = {"dataset":dataset,"fit":fitted,"outer":outer,"outer_summary":summary,"test_metrics":metrics,
              "paired_full_minus":paired,"elapsed_seconds":time.perf_counter()-start,
              "prediction_sha256":hashlib.sha256(predpath.read_bytes()).hexdigest(),
              "source_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "component_selection_source_sha256":hashlib.sha256(oldpath.read_bytes()).hexdigest(),
              "protocol":{"powers":POWERS,"inner_seeds":INNER_SEEDS,"outer_seeds":OUTER_SEEDS,"k":10,
                           "component_candidates_full":45,"fusion_candidates_per_family":45,
                           "test_labels_in_fit":False,"previously_inspected_test_sets":True,
                           "timing_excludes_cached_component_selection":True,"bootstrap_iterations":2000}}
    write_json(target,result)
    print("Completed power",dataset,"seconds",result["elapsed_seconds"],flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset",choices=("ACM","DBLP","all"),default="all")
    parser.add_argument("--output-dir",type=Path,default=RESULTS_ROOT/"kernel_power")
    args = parser.parse_args()
    with threadpool_limits(limits=2):
        for dataset in (("ACM","DBLP") if args.dataset == "all" else (args.dataset,)):
            run(dataset,args.output_dir)
