"""DWASim research implementation."""
